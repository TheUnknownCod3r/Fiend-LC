# The Fiend

### LTS Fork Providing Functionality for newer versions than v72.
This version simply provides LTS support for the mod. This does **NOT** mean new features will appear, just that if it breaks, i'll fix it.

This mod adds a new entity into the game. Demon like creature...

This Model is from game called [Rinse and Repeat](https://hadriandev.itch.io/rinse-and-repeat) please check it out if you have time.

## Infomation

The Fiend is an entity that is taller then the player. Hes a black figure with red glow on his face. Deadly demonic creature you wont want to face against. The Fiend will jumpscare you, make you bust out of fear..

This creature can be killed by stun.

## Abilities

- Break Doors

The fiend will break doors if his chasing or inrage. But he cant open doors!!
- Hide

He hides on the walls
- Pro Flashlight pain

He will get stunned after a proflash light enters his face, this doesn't
- Seeking Mode

Acts like the bracken
- Flicker Lights

the light tingles
- Invisible

He will teleport to random player and stand still and wait.
- Rage

He will get mad if you take the Apparatus or flash him too much

- GoodBye BreakerBox

Legit takes the breakerbox out of its hinges with the door aswell

- Funky

Value that increase his speed and his ability chance, this happens when its 15 hours+ ingame.

## Authors

- [@Rolevote](https://www.youtube.com/@rolevote)

- [@HadrianDev](https://twitter.com/HadrianDev)



# Updates
### 50v
- 1.0.1 - Fixed zero speed player after killing.

- 1.0.2 - Fixed Invisible Mode not making the fiend stand still.

- 1.0.3 - Fixed Collision With Player. He can now unhide randomly, Fixed When The Fiend stops working while being in a custom interior.

- 1.0.4 Patched Door not breaking on other players, Fixed audio bugs, Fixed when he collides with another player he doesn't want to kill. Added more configs

- 1.0.5 Fixed his look at player, new pain sound, Eclipsed Mode for fiend, he gets mad after 15 hours in game. Fixed more with turning. Rewritten the read me page..

### 60v
 - 1.0.6 - Fixed not killing player, nerfed the fiend it only kills you when your below 50 hp, the fiend can now be killed by stunning it, thats includes stun grenade.
 - 1.0.7 - The fiend damage has been buffed.

### v73
- 1.0.8 - Fix the Fiend for v73 Update. Rebuilt and patched with new Netcode. Source Pushed to Github.

# Where can I donate?
the creator who made the fiend model - [Hadrian](https://hadriandev.itch.io/)\
Buy an game from his itch.io page to donate! 😊


# Support/Help
If you have any questions please let me know in the Lethal Company modded server
mod-releases > The Fiend